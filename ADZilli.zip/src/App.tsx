import { useState } from 'react';
import { AuthPage } from './components/AuthPage';
import { InstagramConnectionPage } from './components/InstagramConnectionPage';
import { ProductManagerPage } from './components/ProductManagerPage';
import { DashboardPage } from './components/DashboardPage';
import { Sidebar } from './components/Sidebar';
import { getCurrencyByCountry, Currency } from './utils/currencies';
import { LanguageProvider } from './utils/LanguageContext';
import { ThemeProvider } from './utils/ThemeContext';

export interface Product {
  id: string;
  name: string;
  description: string;
  quantity: number;
  price: number;
  buyingPrice: number;
  deliveryPrice: number;
  image: string;
  orders?: number;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<'auth' | 'instagram' | 'products' | 'dashboard'>('auth');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [instagramConnected, setInstagramConnected] = useState(false);
  const [userCountry, setUserCountry] = useState('us');
  const [userCurrency, setUserCurrency] = useState<Currency>(getCurrencyByCountry('us'));
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  
  const [products, setProducts] = useState<Product[]>([
    {
      id: '1',
      name: 'Wireless Headphones',
      description: 'Premium noise-canceling headphones',
      quantity: 45,
      price: 89.99,
      buyingPrice: 45.00,
      deliveryPrice: 5.00,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400',
      orders: 34,
    },
    {
      id: '2',
      name: 'Smart Watch',
      description: 'Fitness tracking smartwatch',
      quantity: 12,
      price: 199.99,
      buyingPrice: 120.00,
      deliveryPrice: 5.00,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400',
      orders: 28,
    },
    {
      id: '3',
      name: 'Phone Case',
      description: 'Protective phone case',
      quantity: 67,
      price: 24.99,
      buyingPrice: 8.00,
      deliveryPrice: 3.00,
      image: 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=400',
      orders: 45,
    },
  ]);

  const handleLogin = (country: string) => {
    setIsAuthenticated(true);
    setUserCountry(country);
    setUserCurrency(getCurrencyByCountry(country));
    
    // Smart routing based on Instagram connection and product count
    if (instagramConnected) {
      // Instagram is connected - check if user has products
      if (products.length > 0) {
        setCurrentPage('dashboard');
      } else {
        setCurrentPage('products');
      }
    } else {
      // Instagram not connected - go to Instagram connection page
      setCurrentPage('instagram');
    }
  };

  const handleInstagramConnect = () => {
    setInstagramConnected(true);
    
    // After connecting Instagram, check if user has products
    if (products.length > 0) {
      setCurrentPage('dashboard');
    } else {
      setCurrentPage('products');
    }
  };

  const handleInstagramDisconnect = () => {
    setInstagramConnected(false);
    setCurrentPage('instagram');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setInstagramConnected(false);
    setCurrentPage('auth');
    setSidebarOpen(false);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  const handleNavigateToEdit = (page: 'dashboard' | 'products' | 'instagram', productId?: string) => {
    if (productId) {
      setEditingProductId(productId);
    } else {
      setEditingProductId(null);
    }
    setCurrentPage(page);
  };

  if (!isAuthenticated) {
    return (
      <ThemeProvider>
        <LanguageProvider>
          <AuthPage onLogin={handleLogin} />
        </LanguageProvider>
      </ThemeProvider>
    );
  }

  return (
    <ThemeProvider>
      <LanguageProvider>
        <div className="flex min-h-screen bg-slate-50 dark:bg-slate-900">
        <Sidebar 
          currentPage={currentPage} 
          onNavigate={setCurrentPage}
          instagramConnected={instagramConnected}
          isOpen={sidebarOpen}
          onToggle={toggleSidebar}
          onLogout={handleLogout}
        />
        <main className="flex-1 w-full">
          {currentPage === 'instagram' && (
            <InstagramConnectionPage 
              onConnect={handleInstagramConnect}
              onDisconnect={handleInstagramDisconnect}
              isConnected={instagramConnected}
              onMenuClick={toggleSidebar}
            />
          )}
          {currentPage === 'products' && (
            <ProductManagerPage 
              currency={userCurrency} 
              onMenuClick={toggleSidebar}
              products={products}
              setProducts={setProducts}
              initialEditingId={editingProductId}
              onEditComplete={() => setEditingProductId(null)}
            />
          )}
          {currentPage === 'dashboard' && (
            <DashboardPage 
              currency={userCurrency} 
              onMenuClick={toggleSidebar}
              products={products}
              onNavigate={handleNavigateToEdit}
            />
          )}
        </main>
        </div>
      </LanguageProvider>
    </ThemeProvider>
  );
}
