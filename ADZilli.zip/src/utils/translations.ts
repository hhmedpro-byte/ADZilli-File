export type Language = 'en' | 'fr' | 'ar';

export interface Translations {
  // Auth Page
  auth: {
    title: string;
    subtitle: string;
    email: string;
    password: string;
    country: string;
    phone: string;
    signIn: string;
    signUp: string;
    noAccount: string;
    haveAccount: string;
    countries: {
      us: string;
      uk: string;
      fr: string;
      de: string;
      sa: string;
      ae: string;
      eg: string;
      ma: string;
    };
  };
  // Instagram Connection
  instagram: {
    title: string;
    subtitle: string;
    connect: string;
    disconnect: string;
    connected: string;
    disconnected: string;
    benefits: {
      title: string;
      sync: string;
      auto: string;
      insights: string;
    };
  };
  // Product Manager
  products: {
    title: string;
    subtitle: string;
    count: string;
    addProduct: string;
    updateProduct: string;
    saveProduct: string;
    cancelEdit: string;
    yourProducts: string;
    name: string;
    description: string;
    quantity: string;
    price: string;
    buyingPrice: string;
    deliveryPrice: string;
    photos: string;
    uploadText: string;
    uploadHint: string;
    lowStock: string;
    inStock: string;
    orders: string;
    edit: string;
    delete: string;
    sorting: {
      mostSelling: string;
      mostProfiting: string;
      lastAdded: string;
    };
  };
  // Dashboard
  dashboard: {
    title: string;
    subtitle: string;
    totalOrders: string;
    netRevenue: string;
    activeProducts: string;
    lowStock: string;
    productsOverview: string;
    recentOrders: string;
    product: string;
    buyer: string;
    status: string;
    addProduct: string;
    productName: string;
    remainingStock: string;
    units: string;
    actions: string;
    premium: {
      title: string;
      description: string;
      button: string;
    };
    statuses: {
      delivered: string;
      processing: string;
      shipped: string;
    };
  };
  // Sidebar
  sidebar: {
    dashboard: string;
    products: string;
    instagram: string;
    logout: string;
  };
  // Common
  common: {
    currency: string;
    loading: string;
    save: string;
    cancel: string;
    close: string;
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    auth: {
      title: 'Welcome to InstaCommerce AI',
      subtitle: 'Sign in to manage your Instagram e-commerce store',
      email: 'Email Address',
      password: 'Password',
      country: 'Country',
      phone: 'Phone Number',
      signIn: 'Sign In',
      signUp: 'Sign Up',
      noAccount: "Don't have an account?",
      haveAccount: 'Already have an account?',
      countries: {
        us: 'United States',
        uk: 'United Kingdom',
        fr: 'France',
        de: 'Germany',
        sa: 'Saudi Arabia',
        ae: 'United Arab Emirates',
        eg: 'Egypt',
        ma: 'Morocco',
      },
    },
    instagram: {
      title: 'Connect Your Instagram',
      subtitle: 'Link your Instagram business account to start selling',
      connect: 'Connect Instagram Account',
      disconnect: 'Disconnect Instagram',
      connected: 'Instagram Connected',
      disconnected: 'Instagram Not Connected',
      benefits: {
        title: 'Why Connect Instagram?',
        sync: 'Sync your products directly to Instagram',
        auto: 'Automatic order management',
        insights: 'Get detailed analytics and insights',
      },
    },
    products: {
      title: 'Product Manager',
      subtitle: 'Add and manage your Instagram store products',
      count: 'Products',
      addProduct: 'Add New Product',
      updateProduct: 'Update Product',
      saveProduct: 'Save Product',
      cancelEdit: 'Cancel Edit',
      yourProducts: 'Your Products',
      name: 'Product Name',
      description: 'Description',
      quantity: 'Quantity in Stock',
      price: 'Selling Price',
      buyingPrice: 'Buying Price',
      deliveryPrice: 'Delivery Price',
      photos: 'Product Photos',
      uploadText: 'Click to upload or drag and drop',
      uploadHint: 'PNG, JPG up to 10MB',
      lowStock: 'Low Stock',
      inStock: 'in stock',
      orders: 'orders',
      edit: 'Edit',
      delete: 'Delete',
      sorting: {
        mostSelling: 'Most Selling',
        mostProfiting: 'Most Profiting',
        lastAdded: 'Last Added',
      },
    },
    dashboard: {
      title: 'Dashboard',
      subtitle: 'Overview of your Instagram store performance',
      totalOrders: 'Total Orders',
      netRevenue: 'Net Revenue',
      activeProducts: 'Active Products',
      lowStock: 'Low Stock Items',
      productsOverview: 'Products Overview',
      recentOrders: 'Recent Orders',
      product: 'Product',
      buyer: 'Buyer',
      status: 'Status',
      addProduct: 'Add Product',
      productName: 'Product Name',
      remainingStock: 'Remaining Stock',
      units: 'units',
      actions: 'Actions',
      premium: {
        title: 'Upgrade to Premium',
        description: 'Unlock advanced analytics, automation tools, and priority support',
        button: 'Learn More',
      },
      statuses: {
        delivered: 'Delivered',
        processing: 'Processing',
        shipped: 'Shipped',
      },
    },
    sidebar: {
      dashboard: 'Dashboard',
      products: 'Products',
      instagram: 'Instagram',
      logout: 'Logout',
    },
    common: {
      currency: 'Currency',
      loading: 'Loading...',
      save: 'Save',
      cancel: 'Cancel',
      close: 'Close',
    },
  },
  fr: {
    auth: {
      title: 'Bienvenue sur InstaCommerce AI',
      subtitle: 'Connectez-vous pour gérer votre boutique Instagram',
      email: 'Adresse e-mail',
      password: 'Mot de passe',
      country: 'Pays',
      phone: 'Numéro de téléphone',
      signIn: 'Se connecter',
      signUp: "S'inscrire",
      noAccount: "Vous n'avez pas de compte?",
      haveAccount: 'Vous avez déjà un compte?',
      countries: {
        us: 'États-Unis',
        uk: 'Royaume-Uni',
        fr: 'France',
        de: 'Allemagne',
        sa: 'Arabie Saoudite',
        ae: 'Émirats Arabes Unis',
        eg: 'Égypte',
        ma: 'Maroc',
      },
    },
    instagram: {
      title: 'Connectez votre Instagram',
      subtitle: 'Liez votre compte professionnel Instagram pour commencer à vendre',
      connect: 'Connecter le compte Instagram',
      disconnect: 'Déconnecter Instagram',
      connected: 'Instagram connecté',
      disconnected: 'Instagram non connecté',
      benefits: {
        title: 'Pourquoi connecter Instagram?',
        sync: 'Synchronisez vos produits directement sur Instagram',
        auto: 'Gestion automatique des commandes',
        insights: 'Obtenez des analyses et des insights détaillés',
      },
    },
    products: {
      title: 'Gestionnaire de produits',
      subtitle: 'Ajoutez et gérez les produits de votre boutique Instagram',
      count: 'Produits',
      addProduct: 'Ajouter un nouveau produit',
      updateProduct: 'Mettre à jour le produit',
      saveProduct: 'Enregistrer le produit',
      cancelEdit: 'Annuler la modification',
      yourProducts: 'Vos produits',
      name: 'Nom du produit',
      description: 'Description',
      quantity: 'Quantité en stock',
      price: 'Prix de vente',
      buyingPrice: "Prix d'achat",
      deliveryPrice: 'Prix de livraison',
      photos: 'Photos du produit',
      uploadText: 'Cliquez pour télécharger ou glissez-déposez',
      uploadHint: 'PNG, JPG jusqu\'à 10 Mo',
      lowStock: 'Stock faible',
      inStock: 'en stock',
      orders: 'commandes',
      edit: 'Modifier',
      delete: 'Supprimer',
      sorting: {
        mostSelling: 'Plus vendus',
        mostProfiting: 'Plus rentables',
        lastAdded: 'Derniers ajoutés',
      },
    },
    dashboard: {
      title: 'Tableau de bord',
      subtitle: 'Aperçu des performances de votre boutique Instagram',
      totalOrders: 'Commandes totales',
      netRevenue: 'Revenu net',
      activeProducts: 'Produits actifs',
      lowStock: 'Articles en stock faible',
      productsOverview: 'Aperçu des produits',
      recentOrders: 'Commandes récentes',
      product: 'Produit',
      buyer: 'Acheteur',
      status: 'Statut',
      addProduct: 'Ajouter un produit',
      productName: 'Nom du produit',
      remainingStock: 'Stock restant',
      units: 'unités',
      actions: 'Actions',
      premium: {
        title: 'Passer au Premium',
        description: 'Débloquez des analyses avancées, des outils d\'automation et un support prioritaire',
        button: 'En savoir plus',
      },
      statuses: {
        delivered: 'Livré',
        processing: 'En cours',
        shipped: 'Expédié',
      },
    },
    sidebar: {
      dashboard: 'Tableau de bord',
      products: 'Produits',
      instagram: 'Instagram',
      logout: 'Déconnexion',
    },
    common: {
      currency: 'Devise',
      loading: 'Chargement...',
      save: 'Enregistrer',
      cancel: 'Annuler',
      close: 'Fermer',
    },
  },
  ar: {
    auth: {
      title: 'مرحباً بك في InstaCommerce AI',
      subtitle: 'قم بتسجيل الدخول لإدارة متجر Instagram الخاص بك',
      email: 'البريد الإلكتروني',
      password: 'كلمة المرور',
      country: 'الدولة',
      phone: 'رقم الهاتف',
      signIn: 'تسجيل الدخول',
      signUp: 'إنشاء حساب',
      noAccount: 'ليس لديك حساب؟',
      haveAccount: 'هل لديك حساب بالفعل؟',
      countries: {
        us: 'الولايات المتحدة',
        uk: 'المملكة المتحدة',
        fr: 'فرنسا',
        de: 'ألمانيا',
        sa: 'السعودية',
        ae: 'الإمارات العربية المتحدة',
        eg: 'مصر',
        ma: 'المغرب',
      },
    },
    instagram: {
      title: 'ربط حساب Instagram',
      subtitle: 'اربط حساب Instagram التجاري الخاص بك لبدء البيع',
      connect: 'ربط حساب Instagram',
      disconnect: 'قطع الاتصال بـ Instagram',
      connected: 'Instagram متصل',
      disconnected: 'Instagram غير متصل',
      benefits: {
        title: 'لماذا ربط Instagram؟',
        sync: 'مزامنة منتجاتك مباشرة إلى Instagram',
        auto: 'إدارة الطلبات التلقائية',
        insights: 'احصل على تحليلات ورؤى تفصيلية',
      },
    },
    products: {
      title: 'إدارة المنتجات',
      subtitle: 'أضف وأدر منتجات متجر Instagram الخاص بك',
      count: 'منتجات',
      addProduct: 'إضافة منتج جديد',
      updateProduct: 'تحديث المنتج',
      saveProduct: 'حفظ المنتج',
      cancelEdit: 'إلغاء التعديل',
      yourProducts: 'منتجاتك',
      name: 'اسم المنتج',
      description: 'الوصف',
      quantity: 'الكمية في المخزون',
      price: 'سعر البيع',
      buyingPrice: 'سعر الشراء',
      deliveryPrice: 'سعر التوصيل',
      photos: 'صور المنتج',
      uploadText: 'انقر للتحميل أو اسحب وأفلت',
      uploadHint: 'PNG، JPG حتى 10 ميجابايت',
      lowStock: 'مخزون منخفض',
      inStock: 'في المخزون',
      orders: 'طلبات',
      edit: 'تعديل',
      delete: 'حذف',
      sorting: {
        mostSelling: 'الأكثر مبيعاً',
        mostProfiting: 'الأكثر ربحاً',
        lastAdded: 'المضافة مؤخراً',
      },
    },
    dashboard: {
      title: 'لوحة التحكم',
      subtitle: 'نظرة عامة على أداء متجر Instagram الخاص بك',
      totalOrders: 'إجمالي الطلبات',
      netRevenue: 'صافي الإيرادات',
      activeProducts: 'المنتجات النشطة',
      lowStock: 'منتجات المخزون المنخفض',
      productsOverview: 'نظرة عامة على المنتجات',
      recentOrders: 'الطلبات الأخيرة',
      product: 'المنتج',
      buyer: 'المشتري',
      status: 'الحالة',
      addProduct: 'إضافة منتج',
      productName: 'اسم المنتج',
      remainingStock: 'المخزون المتبقي',
      units: 'وحدات',
      actions: 'الإجراءات',
      premium: {
        title: 'الترقية إلى بريميوم',
        description: 'افتح التحليلات المتقدمة وأدوات الأتمتة والدعم ذو الأولوية',
        button: 'معرفة المزيد',
      },
      statuses: {
        delivered: 'تم التوصيل',
        processing: 'قيد المعالجة',
        shipped: 'تم الشحن',
      },
    },
    sidebar: {
      dashboard: 'لوحة التحكم',
      products: 'المنتجات',
      instagram: 'Instagram',
      logout: 'تسجيل الخروج',
    },
    common: {
      currency: 'العملة',
      loading: 'جاري التحميل...',
      save: 'حفظ',
      cancel: 'إلغاء',
      close: 'إغلاق',
    },
  },
};

export function getTranslations(lang: Language): Translations {
  return translations[lang] || translations.en;
}

export const languages = [
  { code: 'en' as Language, name: 'English', flag: '🇬🇧' },
  { code: 'fr' as Language, name: 'Français', flag: '🇫🇷' },
  { code: 'ar' as Language, name: 'العربية', flag: '🇸🇦' },
];
