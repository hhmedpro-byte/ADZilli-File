import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card } from './ui/card';
import { Package, ShoppingBag, Store } from 'lucide-react';
import { useLanguage } from '../utils/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { ThemeToggle } from './ThemeToggle';

interface AuthPageProps {
  onLogin: (country: string) => void;
}

const countryPhoneCodes: Record<string, string> = {
  af: '+93', al: '+355', dz: '+213', ad: '+376', ao: '+244', ag: '+1-268', ar: '+54', am: '+374',
  au: '+61', at: '+43', az: '+994', bs: '+1-242', bh: '+973', bd: '+880', bb: '+1-246', by: '+375',
  be: '+32', bz: '+501', bj: '+229', bt: '+975', bo: '+591', ba: '+387', bw: '+267', br: '+55',
  bn: '+673', bg: '+359', bf: '+226', bi: '+257', kh: '+855', cm: '+237', ca: '+1', cv: '+238',
  cf: '+236', td: '+235', cl: '+56', cn: '+86', co: '+57', km: '+269', cg: '+242', cr: '+506',
  hr: '+385', cu: '+53', cy: '+357', cz: '+420', dk: '+45', dj: '+253', dm: '+1-767', do: '+1-809',
  ec: '+593', eg: '+20', sv: '+503', gq: '+240', er: '+291', ee: '+372', et: '+251', fj: '+679',
  fi: '+358', fr: '+33', ga: '+241', gm: '+220', ge: '+995', de: '+49', gh: '+233', gr: '+30',
  gd: '+1-473', gt: '+502', gn: '+224', gw: '+245', gy: '+592', ht: '+509', hn: '+504', hu: '+36',
  is: '+354', in: '+91', id: '+62', ir: '+98', iq: '+964', ie: '+353', il: '+972', it: '+39',
  jm: '+1-876', jp: '+81', jo: '+962', kz: '+7', ke: '+254', ki: '+686', kp: '+850', kr: '+82',
  kw: '+965', kg: '+996', la: '+856', lv: '+371', lb: '+961', ls: '+266', lr: '+231', ly: '+218',
  li: '+423', lt: '+370', lu: '+352', mk: '+389', mg: '+261', mw: '+265', my: '+60', mv: '+960',
  ml: '+223', mt: '+356', mh: '+692', mr: '+222', mu: '+230', mx: '+52', fm: '+691', md: '+373',
  mc: '+377', mn: '+976', me: '+382', ma: '+212', mz: '+258', mm: '+95', na: '+264', nr: '+674',
  np: '+977', nl: '+31', nz: '+64', ni: '+505', ne: '+227', ng: '+234', no: '+47', om: '+968',
  pk: '+92', pw: '+680', pa: '+507', pg: '+675', py: '+595', pe: '+51', ph: '+63', pl: '+48',
  pt: '+351', qa: '+974', ro: '+40', ru: '+7', rw: '+250', kn: '+1-869', lc: '+1-758', vc: '+1-784',
  ws: '+685', sm: '+378', st: '+239', sa: '+966', sn: '+221', rs: '+381', sc: '+248', sl: '+232',
  sg: '+65', sk: '+421', si: '+386', sb: '+677', so: '+252', za: '+27', ss: '+211', es: '+34',
  lk: '+94', sd: '+249', sr: '+597', sz: '+268', se: '+46', ch: '+41', sy: '+963', tw: '+886',
  tj: '+992', tz: '+255', th: '+66', tl: '+670', tg: '+228', to: '+676', tt: '+1-868', tn: '+216',
  tr: '+90', tm: '+993', tv: '+688', ug: '+256', ua: '+380', ae: '+971', uk: '+44', us: '+1',
  uy: '+598', uz: '+998', vu: '+678', va: '+39', ve: '+58', vn: '+84', ye: '+967', zm: '+260', zw: '+263'
};

export function AuthPage({ onLogin }: AuthPageProps) {
  const { t } = useLanguage();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    country: '',
    phone: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(formData.country || 'us');
  };

  const getPhoneCode = () => {
    return formData.country ? countryPhoneCodes[formData.country] || '+1' : '+1';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 flex items-center justify-center p-4">
      <div className="absolute top-4 right-4 z-50 flex items-center gap-2">
        <ThemeToggle />
        <LanguageSelector />
      </div>
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-400/10 dark:bg-blue-400/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-violet-400/10 dark:bg-violet-400/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-6xl grid md:grid-cols-2 gap-8 items-center relative z-10">
        <div className="space-y-6 p-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center">
              <Package className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-slate-900 dark:text-slate-100">InstaCommerce AI</h1>
              <p className="text-slate-600 dark:text-slate-400">AI-Driven Instagram E-commerce</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                <ShoppingBag className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="text-slate-900 dark:text-slate-100">Automated Product Management</h3>
                <p className="text-slate-600 dark:text-slate-400">Manage your Instagram store products with AI-powered automation</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center flex-shrink-0">
                <Store className="w-6 h-6 text-violet-600 dark:text-violet-400" />
              </div>
              <div>
                <h3 className="text-slate-900 dark:text-slate-100">Global Multi-Country Support</h3>
                <p className="text-slate-600 dark:text-slate-400">Sell to customers worldwide with localized pricing and delivery</p>
              </div>
            </div>
          </div>
        </div>

        <Card className="p-8 rounded-3xl shadow-2xl border-0 bg-white/80 dark:bg-slate-800/80 backdrop-blur">
          <div className="text-center mb-6">
            <h2 className="text-slate-900 dark:text-slate-100 mb-2">{t.auth.title}</h2>
            <p className="text-slate-600 dark:text-slate-400">{t.auth.subtitle}</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="email">{t.auth.email}</Label>
              <Input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="rounded-xl h-12"
                required
              />
            </div>

            <div>
              <Label htmlFor="password">{t.auth.password}</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="rounded-xl h-12"
                required
              />
            </div>

            {!isLogin && (
              <>
                <div>
                  <Label htmlFor="country">{t.auth.country}</Label>
                  <Select
                    value={formData.country}
                    onValueChange={(value) => setFormData({ ...formData, country: value })}
                    required
                  >
                    <SelectTrigger className="rounded-xl h-12">
                      <SelectValue placeholder={t.auth.country} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="af">Afghanistan</SelectItem>
                      <SelectItem value="al">Albania</SelectItem>
                      <SelectItem value="dz">Algeria</SelectItem>
                      <SelectItem value="ad">Andorra</SelectItem>
                      <SelectItem value="ao">Angola</SelectItem>
                      <SelectItem value="ag">Antigua and Barbuda</SelectItem>
                      <SelectItem value="ar">Argentina</SelectItem>
                      <SelectItem value="am">Armenia</SelectItem>
                      <SelectItem value="au">Australia</SelectItem>
                      <SelectItem value="at">Austria</SelectItem>
                      <SelectItem value="az">Azerbaijan</SelectItem>
                      <SelectItem value="bs">Bahamas</SelectItem>
                      <SelectItem value="bh">Bahrain</SelectItem>
                      <SelectItem value="bd">Bangladesh</SelectItem>
                      <SelectItem value="bb">Barbados</SelectItem>
                      <SelectItem value="by">Belarus</SelectItem>
                      <SelectItem value="be">Belgium</SelectItem>
                      <SelectItem value="bz">Belize</SelectItem>
                      <SelectItem value="bj">Benin</SelectItem>
                      <SelectItem value="bt">Bhutan</SelectItem>
                      <SelectItem value="bo">Bolivia</SelectItem>
                      <SelectItem value="ba">Bosnia and Herzegovina</SelectItem>
                      <SelectItem value="bw">Botswana</SelectItem>
                      <SelectItem value="br">Brazil</SelectItem>
                      <SelectItem value="bn">Brunei</SelectItem>
                      <SelectItem value="bg">Bulgaria</SelectItem>
                      <SelectItem value="bf">Burkina Faso</SelectItem>
                      <SelectItem value="bi">Burundi</SelectItem>
                      <SelectItem value="kh">Cambodia</SelectItem>
                      <SelectItem value="cm">Cameroon</SelectItem>
                      <SelectItem value="ca">Canada</SelectItem>
                      <SelectItem value="cv">Cape Verde</SelectItem>
                      <SelectItem value="cf">Central African Republic</SelectItem>
                      <SelectItem value="td">Chad</SelectItem>
                      <SelectItem value="cl">Chile</SelectItem>
                      <SelectItem value="cn">China</SelectItem>
                      <SelectItem value="co">Colombia</SelectItem>
                      <SelectItem value="km">Comoros</SelectItem>
                      <SelectItem value="cg">Congo</SelectItem>
                      <SelectItem value="cr">Costa Rica</SelectItem>
                      <SelectItem value="hr">Croatia</SelectItem>
                      <SelectItem value="cu">Cuba</SelectItem>
                      <SelectItem value="cy">Cyprus</SelectItem>
                      <SelectItem value="cz">Czech Republic</SelectItem>
                      <SelectItem value="dk">Denmark</SelectItem>
                      <SelectItem value="dj">Djibouti</SelectItem>
                      <SelectItem value="dm">Dominica</SelectItem>
                      <SelectItem value="do">Dominican Republic</SelectItem>
                      <SelectItem value="ec">Ecuador</SelectItem>
                      <SelectItem value="eg">Egypt</SelectItem>
                      <SelectItem value="sv">El Salvador</SelectItem>
                      <SelectItem value="gq">Equatorial Guinea</SelectItem>
                      <SelectItem value="er">Eritrea</SelectItem>
                      <SelectItem value="ee">Estonia</SelectItem>
                      <SelectItem value="et">Ethiopia</SelectItem>
                      <SelectItem value="fj">Fiji</SelectItem>
                      <SelectItem value="fi">Finland</SelectItem>
                      <SelectItem value="fr">France</SelectItem>
                      <SelectItem value="ga">Gabon</SelectItem>
                      <SelectItem value="gm">Gambia</SelectItem>
                      <SelectItem value="ge">Georgia</SelectItem>
                      <SelectItem value="de">Germany</SelectItem>
                      <SelectItem value="gh">Ghana</SelectItem>
                      <SelectItem value="gr">Greece</SelectItem>
                      <SelectItem value="gd">Grenada</SelectItem>
                      <SelectItem value="gt">Guatemala</SelectItem>
                      <SelectItem value="gn">Guinea</SelectItem>
                      <SelectItem value="gw">Guinea-Bissau</SelectItem>
                      <SelectItem value="gy">Guyana</SelectItem>
                      <SelectItem value="ht">Haiti</SelectItem>
                      <SelectItem value="hn">Honduras</SelectItem>
                      <SelectItem value="hu">Hungary</SelectItem>
                      <SelectItem value="is">Iceland</SelectItem>
                      <SelectItem value="in">India</SelectItem>
                      <SelectItem value="id">Indonesia</SelectItem>
                      <SelectItem value="ir">Iran</SelectItem>
                      <SelectItem value="iq">Iraq</SelectItem>
                      <SelectItem value="ie">Ireland</SelectItem>
                      <SelectItem value="il">Israel</SelectItem>
                      <SelectItem value="it">Italy</SelectItem>
                      <SelectItem value="jm">Jamaica</SelectItem>
                      <SelectItem value="jp">Japan</SelectItem>
                      <SelectItem value="jo">Jordan</SelectItem>
                      <SelectItem value="kz">Kazakhstan</SelectItem>
                      <SelectItem value="ke">Kenya</SelectItem>
                      <SelectItem value="ki">Kiribati</SelectItem>
                      <SelectItem value="kp">Korea, North</SelectItem>
                      <SelectItem value="kr">Korea, South</SelectItem>
                      <SelectItem value="kw">Kuwait</SelectItem>
                      <SelectItem value="kg">Kyrgyzstan</SelectItem>
                      <SelectItem value="la">Laos</SelectItem>
                      <SelectItem value="lv">Latvia</SelectItem>
                      <SelectItem value="lb">Lebanon</SelectItem>
                      <SelectItem value="ls">Lesotho</SelectItem>
                      <SelectItem value="lr">Liberia</SelectItem>
                      <SelectItem value="ly">Libya</SelectItem>
                      <SelectItem value="li">Liechtenstein</SelectItem>
                      <SelectItem value="lt">Lithuania</SelectItem>
                      <SelectItem value="lu">Luxembourg</SelectItem>
                      <SelectItem value="mk">Macedonia</SelectItem>
                      <SelectItem value="mg">Madagascar</SelectItem>
                      <SelectItem value="mw">Malawi</SelectItem>
                      <SelectItem value="my">Malaysia</SelectItem>
                      <SelectItem value="mv">Maldives</SelectItem>
                      <SelectItem value="ml">Mali</SelectItem>
                      <SelectItem value="mt">Malta</SelectItem>
                      <SelectItem value="mh">Marshall Islands</SelectItem>
                      <SelectItem value="mr">Mauritania</SelectItem>
                      <SelectItem value="mu">Mauritius</SelectItem>
                      <SelectItem value="mx">Mexico</SelectItem>
                      <SelectItem value="fm">Micronesia</SelectItem>
                      <SelectItem value="md">Moldova</SelectItem>
                      <SelectItem value="mc">Monaco</SelectItem>
                      <SelectItem value="mn">Mongolia</SelectItem>
                      <SelectItem value="me">Montenegro</SelectItem>
                      <SelectItem value="ma">Morocco</SelectItem>
                      <SelectItem value="mz">Mozambique</SelectItem>
                      <SelectItem value="mm">Myanmar</SelectItem>
                      <SelectItem value="na">Namibia</SelectItem>
                      <SelectItem value="nr">Nauru</SelectItem>
                      <SelectItem value="np">Nepal</SelectItem>
                      <SelectItem value="nl">Netherlands</SelectItem>
                      <SelectItem value="nz">New Zealand</SelectItem>
                      <SelectItem value="ni">Nicaragua</SelectItem>
                      <SelectItem value="ne">Niger</SelectItem>
                      <SelectItem value="ng">Nigeria</SelectItem>
                      <SelectItem value="no">Norway</SelectItem>
                      <SelectItem value="om">Oman</SelectItem>
                      <SelectItem value="pk">Pakistan</SelectItem>
                      <SelectItem value="pw">Palau</SelectItem>
                      <SelectItem value="pa">Panama</SelectItem>
                      <SelectItem value="pg">Papua New Guinea</SelectItem>
                      <SelectItem value="py">Paraguay</SelectItem>
                      <SelectItem value="pe">Peru</SelectItem>
                      <SelectItem value="ph">Philippines</SelectItem>
                      <SelectItem value="pl">Poland</SelectItem>
                      <SelectItem value="pt">Portugal</SelectItem>
                      <SelectItem value="qa">Qatar</SelectItem>
                      <SelectItem value="ro">Romania</SelectItem>
                      <SelectItem value="ru">Russia</SelectItem>
                      <SelectItem value="rw">Rwanda</SelectItem>
                      <SelectItem value="kn">Saint Kitts and Nevis</SelectItem>
                      <SelectItem value="lc">Saint Lucia</SelectItem>
                      <SelectItem value="vc">Saint Vincent and the Grenadines</SelectItem>
                      <SelectItem value="ws">Samoa</SelectItem>
                      <SelectItem value="sm">San Marino</SelectItem>
                      <SelectItem value="st">Sao Tome and Principe</SelectItem>
                      <SelectItem value="sa">Saudi Arabia</SelectItem>
                      <SelectItem value="sn">Senegal</SelectItem>
                      <SelectItem value="rs">Serbia</SelectItem>
                      <SelectItem value="sc">Seychelles</SelectItem>
                      <SelectItem value="sl">Sierra Leone</SelectItem>
                      <SelectItem value="sg">Singapore</SelectItem>
                      <SelectItem value="sk">Slovakia</SelectItem>
                      <SelectItem value="si">Slovenia</SelectItem>
                      <SelectItem value="sb">Solomon Islands</SelectItem>
                      <SelectItem value="so">Somalia</SelectItem>
                      <SelectItem value="za">South Africa</SelectItem>
                      <SelectItem value="ss">South Sudan</SelectItem>
                      <SelectItem value="es">Spain</SelectItem>
                      <SelectItem value="lk">Sri Lanka</SelectItem>
                      <SelectItem value="sd">Sudan</SelectItem>
                      <SelectItem value="sr">Suriname</SelectItem>
                      <SelectItem value="sz">Swaziland</SelectItem>
                      <SelectItem value="se">Sweden</SelectItem>
                      <SelectItem value="ch">Switzerland</SelectItem>
                      <SelectItem value="sy">Syria</SelectItem>
                      <SelectItem value="tw">Taiwan</SelectItem>
                      <SelectItem value="tj">Tajikistan</SelectItem>
                      <SelectItem value="tz">Tanzania</SelectItem>
                      <SelectItem value="th">Thailand</SelectItem>
                      <SelectItem value="tl">Timor-Leste</SelectItem>
                      <SelectItem value="tg">Togo</SelectItem>
                      <SelectItem value="to">Tonga</SelectItem>
                      <SelectItem value="tt">Trinidad and Tobago</SelectItem>
                      <SelectItem value="tn">Tunisia</SelectItem>
                      <SelectItem value="tr">Turkey</SelectItem>
                      <SelectItem value="tm">Turkmenistan</SelectItem>
                      <SelectItem value="tv">Tuvalu</SelectItem>
                      <SelectItem value="ug">Uganda</SelectItem>
                      <SelectItem value="ua">Ukraine</SelectItem>
                      <SelectItem value="ae">United Arab Emirates</SelectItem>
                      <SelectItem value="uk">United Kingdom</SelectItem>
                      <SelectItem value="us">United States</SelectItem>
                      <SelectItem value="uy">Uruguay</SelectItem>
                      <SelectItem value="uz">Uzbekistan</SelectItem>
                      <SelectItem value="vu">Vanuatu</SelectItem>
                      <SelectItem value="va">Vatican City</SelectItem>
                      <SelectItem value="ve">Venezuela</SelectItem>
                      <SelectItem value="vn">Vietnam</SelectItem>
                      <SelectItem value="ye">Yemen</SelectItem>
                      <SelectItem value="zm">Zambia</SelectItem>
                      <SelectItem value="zw">Zimbabwe</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="phone">{t.auth.phone}</Label>
                  <div className="flex gap-2">
                    <div className="w-24 h-12 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-400">
                      {getPhoneCode()}
                    </div>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="555 000 0000"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="rounded-xl h-12 flex-1"
                      required={!isLogin}
                    />
                  </div>
                </div>
              </>
            )}

            <Button
              type="submit"
              className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-600 hover:to-violet-700"
            >
              {isLogin ? t.auth.signIn : t.auth.signUp}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <p className="text-slate-600 dark:text-slate-400">
              {isLogin ? t.auth.noAccount : t.auth.haveAccount}{' '}
              <button
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="text-blue-600 dark:text-blue-400 hover:underline"
              >
                {isLogin ? t.auth.signUp : t.auth.signIn}
              </button>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
