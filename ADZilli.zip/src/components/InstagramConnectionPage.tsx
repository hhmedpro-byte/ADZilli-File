import { Card } from './ui/card';
import { Button } from './ui/button';
import { Instagram, CheckCircle2, User, Menu } from 'lucide-react';
import { useLanguage } from '../utils/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { ThemeToggle } from './ThemeToggle';

interface InstagramConnectionPageProps {
  onConnect: () => void;
  onDisconnect: () => void;
  isConnected: boolean;
  onMenuClick: () => void;
}

export function InstagramConnectionPage({ onConnect, onDisconnect, isConnected, onMenuClick }: InstagramConnectionPageProps) {
  const { t } = useLanguage();
  
  return (
    <div className="min-h-screen w-full">
      <div className="w-full h-full p-4 md:p-8">
        <div className="max-w-2xl mx-auto">
          <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-4">
              <button
                onClick={onMenuClick}
                className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <Menu className="w-6 h-6 text-slate-600 dark:text-slate-300" />
              </button>
              <div>
                <h1 className="text-slate-900 dark:text-slate-100 mb-2">{t.instagram.title}</h1>
                <p className="text-slate-600 dark:text-slate-400 hidden sm:block">{t.instagram.subtitle}</p>
              </div>
            </div>
            <div className="flex items-center gap-2 justify-end">
              <ThemeToggle />
              <LanguageSelector />
            </div>
          </div>

          <Card className="p-8 rounded-3xl border-0 shadow-lg bg-white dark:bg-slate-800">
            <div className="text-center space-y-6">
              <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-pink-500 via-purple-500 to-orange-500 flex items-center justify-center">
                <Instagram className="w-10 h-10 text-white" />
              </div>

              {!isConnected ? (
                <>
                  <div>
                    <h2 className="text-slate-900 dark:text-slate-100 mb-2">{t.instagram.connect}</h2>
                    <p className="text-slate-600 dark:text-slate-400">{t.instagram.subtitle}</p>
                  </div>

                  <div className="bg-slate-50 dark:bg-slate-700/50 rounded-2xl p-6 space-y-3 text-left">
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-slate-900 dark:text-slate-100">{t.instagram.benefits.sync}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-slate-900 dark:text-slate-100">{t.instagram.benefits.auto}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-slate-900 dark:text-slate-100">{t.instagram.benefits.insights}</p>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={onConnect}
                    className="w-full h-14 rounded-xl bg-gradient-to-r from-pink-500 via-purple-500 to-orange-500 hover:from-pink-600 hover:via-purple-600 hover:to-orange-600"
                  >
                    <Instagram className="w-5 h-5 mr-2" />
                    {t.instagram.connect}
                  </Button>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 mx-auto rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8 text-green-600" />
                  </div>

                  <div>
                    <h2 className="text-slate-900 dark:text-slate-100 mb-2">{t.instagram.connected}</h2>
                    <p className="text-slate-600 dark:text-slate-400">{t.instagram.subtitle}</p>
                  </div>

                  <Card className="bg-gradient-to-br from-blue-50 to-violet-50 dark:from-blue-900/20 dark:to-violet-900/20 border-0 p-6 rounded-2xl">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center">
                        <User className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-left">
                        <p className="text-slate-900 dark:text-slate-100">@your_instagram_store</p>
                        <p className="text-sm text-slate-600 dark:text-slate-400">Instagram Business Account</p>
                      </div>
                    </div>
                  </Card>

                  <Button
                    variant="outline"
                    onClick={onDisconnect}
                    className="w-full h-12 rounded-xl border-slate-200"
                  >
                    {t.instagram.disconnect}
                  </Button>
                </>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
