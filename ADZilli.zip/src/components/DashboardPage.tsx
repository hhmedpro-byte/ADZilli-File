import { useState } from 'react';
import { Card } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { DollarSign, ShoppingCart, TrendingUp, AlertTriangle, Menu, Plus, Edit } from 'lucide-react';
import { Currency, formatPrice } from '../utils/currencies';
import { Product } from '../App';
import { useLanguage } from '../utils/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { ThemeToggle } from './ThemeToggle';

interface DashboardPageProps {
  currency: Currency;
  onMenuClick: () => void;
  products: Product[];
  onNavigate: (page: 'dashboard' | 'products' | 'instagram', productId?: string) => void;
}

export function DashboardPage({ currency, onMenuClick, products, onNavigate }: DashboardPageProps) {
  const { t } = useLanguage();
  const [sortBy, setSortBy] = useState<'mostSelling' | 'mostProfiting' | 'lastAdded'>('mostSelling');

  // Calculate totals from products
  const totalOrders = products.reduce((sum, p) => sum + (p.orders || 0), 0);
  const netRevenue = products.reduce((sum, p) => {
    const profit = (p.price - p.buyingPrice) * (p.orders || 0);
    return sum + profit;
  }, 0);
  const lowStockCount = products.filter(p => p.quantity < 20).length;

  // Sort products based on selected method
  const sortedProducts = [...products].sort((a, b) => {
    if (sortBy === 'mostSelling') {
      return (b.orders || 0) - (a.orders || 0);
    } else if (sortBy === 'mostProfiting') {
      const profitA = (a.price - a.buyingPrice) * (a.orders || 0);
      const profitB = (b.price - b.buyingPrice) * (b.orders || 0);
      return profitB - profitA;
    } else {
      // lastAdded - newest first (higher IDs are newer)
      return parseInt(b.id) - parseInt(a.id);
    }
  });
  const stats = [
    {
      label: t.dashboard.totalOrders,
      value: totalOrders.toString(),
      change: '+12.5%',
      icon: ShoppingCart,
      color: 'blue',
    },
    {
      label: t.dashboard.netRevenue,
      value: formatPrice(netRevenue, currency),
      change: '+8.2%',
      icon: DollarSign,
      color: 'green',
    },
    {
      label: t.dashboard.activeProducts,
      value: products.length.toString(),
      change: '+5.1%',
      icon: TrendingUp,
      color: 'violet',
    },
    {
      label: t.dashboard.lowStock,
      value: lowStockCount.toString(),
      change: '-2',
      icon: AlertTriangle,
      color: 'orange',
    },
  ];

  const orders = [
    { id: 1, product: 'Wireless Headphones', quantity: 2, buyer: 'John Smith', status: 'delivered' },
    { id: 2, product: 'Smart Watch', quantity: 1, buyer: 'Sarah Johnson', status: 'processing' },
    { id: 3, product: 'Wireless Headphones', quantity: 1, buyer: 'Mike Brown', status: 'shipped' },
    { id: 4, product: 'Phone Case', quantity: 3, buyer: 'Emma Wilson', status: 'delivered' },
    { id: 5, product: 'Smart Watch', quantity: 1, buyer: 'James Davis', status: 'processing' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered':
        return 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 hover:bg-green-100 dark:hover:bg-green-900/30';
      case 'processing':
        return 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/30';
      case 'shipped':
        return 'bg-violet-100 dark:bg-violet-900/30 text-violet-700 dark:text-violet-400 hover:bg-violet-100 dark:hover:bg-violet-900/30';
      default:
        return 'bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'delivered':
        return t.dashboard.statuses.delivered;
      case 'processing':
        return t.dashboard.statuses.processing;
      case 'shipped':
        return t.dashboard.statuses.shipped;
      default:
        return status;
    }
  };

  return (
    <div className="min-h-screen w-full">
      <div className="w-full h-full p-4 md:p-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <button
              onClick={onMenuClick}
              className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Menu className="w-6 h-6 text-slate-600 dark:text-slate-300" />
            </button>
            <div>
              <h1 className="text-slate-900 dark:text-slate-100 mb-2">{t.dashboard.title}</h1>
              <p className="text-slate-600 dark:text-slate-400 hidden sm:block">{t.dashboard.subtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 justify-end">
            <ThemeToggle />
            <LanguageSelector />
            <Button
              onClick={() => onNavigate('products')}
              className="h-12 rounded-xl bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-600 hover:to-violet-700"
            >
              <Plus className="w-5 h-5 md:mr-2" />
              <span className="hidden md:inline">{t.dashboard.addProduct}</span>
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {stats.slice(0, 2).map((stat) => {
            const Icon = stat.icon;
            const colorClasses = {
              blue: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',
              green: 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400',
              violet: 'bg-violet-100 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400',
              orange: 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400',
            }[stat.color];

            return (
              <Card key={stat.label} className="p-6 rounded-3xl border-0 shadow-lg bg-white dark:bg-slate-800">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-2xl ${colorClasses} flex items-center justify-center`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-sm text-green-600 dark:text-green-400">{stat.change}</span>
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">{stat.label}</p>
                  <p className="text-slate-900 dark:text-slate-100">{stat.value}</p>
                </div>
              </Card>
            );
          })}
        </div>

        <Card className="p-6 rounded-3xl border-0 shadow-lg bg-white dark:bg-slate-800">
          <h2 className="text-slate-900 dark:text-slate-100 mb-6">{t.dashboard.recentOrders}</h2>
            <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-700">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.product}</TableHead>
                    <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.buyer}</TableHead>
                    <TableHead className="text-slate-600 dark:text-slate-400">Qty</TableHead>
                    <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.status}</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell className="text-slate-900 dark:text-slate-100">{order.product}</TableCell>
                      <TableCell className="text-slate-900 dark:text-slate-100">{order.buyer}</TableCell>
                      <TableCell className="text-slate-900 dark:text-slate-100">{order.quantity}</TableCell>
                      <TableCell>
                        <Badge className={`${getStatusColor(order.status)} rounded-full capitalize`}>
                          {getStatusText(order.status)}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          {stats.slice(2, 4).map((stat) => {
            const Icon = stat.icon;
            const colorClasses = {
              blue: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',
              green: 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400',
              violet: 'bg-violet-100 dark:bg-violet-900/30 text-violet-600 dark:text-violet-400',
              orange: 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400',
            }[stat.color];

            return (
              <Card key={stat.label} className="p-6 rounded-3xl border-0 shadow-lg bg-white dark:bg-slate-800">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-2xl ${colorClasses} flex items-center justify-center`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-sm text-green-600 dark:text-green-400">{stat.change}</span>
                </div>
                <div>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">{stat.label}</p>
                  <p className="text-slate-900 dark:text-slate-100">{stat.value}</p>
                </div>
              </Card>
            );
          })}
        </div>

        <Card className="p-6 rounded-3xl border-0 shadow-lg bg-white dark:bg-slate-800">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-slate-900 dark:text-slate-100">{t.dashboard.productsOverview}</h2>
            <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
              <SelectTrigger className="w-48 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mostSelling">{t.products.sorting.mostSelling}</SelectItem>
                <SelectItem value="mostProfiting">{t.products.sorting.mostProfiting}</SelectItem>
                <SelectItem value="lastAdded">{t.products.sorting.lastAdded}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="overflow-hidden rounded-2xl border border-slate-200 dark:border-slate-700">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.productName}</TableHead>
                  <TableHead className="text-slate-600 dark:text-slate-400">{t.products.orders}</TableHead>
                  <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.netRevenue}</TableHead>
                  <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.remainingStock}</TableHead>
                  <TableHead className="text-slate-600 dark:text-slate-400">{t.dashboard.actions}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedProducts.map((product) => {
                  const productRevenue = (product.price - product.buyingPrice) * (product.orders || 0);
                  return (
                    <TableRow key={product.id}>
                      <TableCell className="text-slate-900 dark:text-slate-100">{product.name}</TableCell>
                      <TableCell className="text-slate-900 dark:text-slate-100">{product.orders || 0}</TableCell>
                      <TableCell className="text-slate-900 dark:text-slate-100">{formatPrice(productRevenue, currency)}</TableCell>
                      <TableCell>
                        <span className={product.quantity < 20 ? 'text-orange-600 dark:text-orange-400' : 'text-slate-900 dark:text-slate-100'}>
                          {product.quantity} {t.dashboard.units}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onNavigate('products', product.id)}
                          className="rounded-xl"
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          {t.products.edit}
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </Card>

        <Card className="p-6 rounded-3xl border-0 shadow-lg bg-gradient-to-br from-blue-500 to-violet-600 text-white dark:from-blue-600 dark:to-violet-700">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="mb-2">{t.dashboard.premium.title}</h3>
              <p className="text-blue-100 dark:text-blue-200">{t.dashboard.premium.description}</p>
            </div>
            <button className="px-6 py-3 bg-white text-blue-600 rounded-xl hover:bg-blue-50 dark:hover:bg-slate-100 transition-colors">
              {t.dashboard.premium.button}
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
