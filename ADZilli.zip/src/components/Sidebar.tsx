import { LayoutDashboard, Package, Instagram, LogOut, Menu, X } from 'lucide-react';
import { useLanguage } from '../utils/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { ThemeToggle } from './ThemeToggle';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: 'dashboard' | 'products' | 'instagram') => void;
  instagramConnected: boolean;
  isOpen: boolean;
  onToggle: () => void;
  onLogout: () => void;
}

export function Sidebar({ currentPage, onNavigate, instagramConnected, isOpen, onToggle, onLogout }: SidebarProps) {
  const { t } = useLanguage();
  
  const menuItems = [
    { id: 'dashboard', label: t.sidebar.dashboard, icon: LayoutDashboard },
    { id: 'products', label: t.sidebar.products, icon: Package },
    { id: 'instagram', label: t.sidebar.instagram, icon: Instagram },
  ];

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}
      
      {/* Sidebar */}
      <aside className={`
        fixed left-0 top-0 h-screen w-64 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 flex flex-col z-50
        transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center">
              <Package className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-slate-900 dark:text-slate-100">InstaCommerce AI</h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">E-commerce Manager</p>
            </div>
          </div>
          <button 
            onClick={onToggle}
            className="lg:hidden text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            const isDisabled = !instagramConnected && item.id !== 'instagram';

            return (
              <button
                key={item.id}
                onClick={() => {
                  if (!isDisabled) {
                    onNavigate(item.id as any);
                    onToggle();
                  }
                }}
                disabled={isDisabled}
                className={`
                  w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all
                  ${isActive 
                    ? 'bg-gradient-to-r from-blue-500 to-violet-600 text-white shadow-lg shadow-blue-500/20' 
                    : isDisabled
                    ? 'text-slate-300 dark:text-slate-600 cursor-not-allowed'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                  }
                `}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-slate-700 space-y-2">
          <div className="px-2 flex items-center gap-2">
            <ThemeToggle />
            <div className="flex-1">
              <LanguageSelector />
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all"
          >
            <LogOut className="w-5 h-5" />
            <span>{t.sidebar.logout}</span>
          </button>
        </div>
      </aside>
    </>
  );
}
