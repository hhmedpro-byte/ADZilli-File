import { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Plus, Edit, Trash2, Package, Upload, Menu } from 'lucide-react';
import { Badge } from './ui/badge';
import { Currency, formatPrice } from '../utils/currencies';
import { Product } from '../App';
import { useLanguage } from '../utils/LanguageContext';
import { LanguageSelector } from './LanguageSelector';
import { ThemeToggle } from './ThemeToggle';

interface ProductManagerPageProps {
  currency: Currency;
  onMenuClick: () => void;
  products: Product[];
  setProducts: (products: Product[]) => void;
  initialEditingId?: string | null;
  onEditComplete: () => void;
}

export function ProductManagerPage({ currency, onMenuClick, products, setProducts, initialEditingId, onEditComplete }: ProductManagerPageProps) {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    quantity: '',
    price: '',
    buyingPrice: '',
    deliveryPrice: '',
  });

  const [editingId, setEditingId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'mostSelling' | 'mostProfiting' | 'lastAdded'>('lastAdded');

  // Handle initial editing ID from navigation
  useEffect(() => {
    if (initialEditingId) {
      const product = products.find(p => p.id === initialEditingId);
      if (product) {
        handleEdit(product);
      }
      onEditComplete();
    }
  }, [initialEditingId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingId) {
      // Update existing product
      setProducts(products.map(p => 
        p.id === editingId 
          ? {
              ...p,
              name: formData.name,
              description: formData.description,
              quantity: parseInt(formData.quantity),
              price: parseFloat(formData.price),
              buyingPrice: parseFloat(formData.buyingPrice),
              deliveryPrice: parseFloat(formData.deliveryPrice),
            }
          : p
      ));
      setEditingId(null);
    } else {
      // Add new product
      const newProduct: Product = {
        id: Date.now().toString(),
        name: formData.name,
        description: formData.description,
        quantity: parseInt(formData.quantity),
        price: parseFloat(formData.price),
        buyingPrice: parseFloat(formData.buyingPrice),
        deliveryPrice: parseFloat(formData.deliveryPrice),
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400',
        orders: 0,
      };
      setProducts([...products, newProduct]);
    }
    
    setFormData({
      name: '',
      description: '',
      quantity: '',
      price: '',
      buyingPrice: '',
      deliveryPrice: '',
    });
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      description: product.description,
      quantity: product.quantity.toString(),
      price: product.price.toString(),
      buyingPrice: product.buyingPrice.toString(),
      deliveryPrice: product.deliveryPrice.toString(),
    });
    setEditingId(product.id);
    // Scroll to form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData({
      name: '',
      description: '',
      quantity: '',
      price: '',
      buyingPrice: '',
      deliveryPrice: '',
    });
  };

  // Sort products based on selected method
  const sortedProducts = [...products].sort((a, b) => {
    if (sortBy === 'mostSelling') {
      return (b.orders || 0) - (a.orders || 0);
    } else if (sortBy === 'mostProfiting') {
      const profitA = (a.price - a.buyingPrice) * (a.orders || 0);
      const profitB = (b.price - b.buyingPrice) * (b.orders || 0);
      return profitB - profitA;
    } else {
      // lastAdded - newest first (higher IDs are newer)
      return parseInt(b.id) - parseInt(a.id);
    }
  });

  return (
    <div className="min-h-screen w-full">
      <div className="w-full h-full p-4 md:p-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-center gap-4">
            <button
              onClick={onMenuClick}
              className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Menu className="w-6 h-6 text-slate-600 dark:text-slate-300" />
            </button>
            <div>
              <h1 className="text-slate-900 dark:text-slate-100 mb-2">{t.products.title}</h1>
              <p className="text-slate-600 dark:text-slate-400 hidden sm:block">{t.products.subtitle}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 justify-end">
            <ThemeToggle />
            <LanguageSelector />
            <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800">
              <Package className="w-5 h-5" />
              <span>{products.length} {t.products.count}</span>
            </div>
          </div>
        </div>

        <Card className="p-8 rounded-3xl border-0 shadow-lg bg-white dark:bg-slate-800">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl ${editingId ? 'bg-violet-100 dark:bg-violet-900/30' : 'bg-blue-100 dark:bg-blue-900/30'} flex items-center justify-center`}>
                {editingId ? <Edit className="w-5 h-5 text-violet-600 dark:text-violet-400" /> : <Plus className="w-5 h-5 text-blue-600 dark:text-blue-400" />}
              </div>
              <h2 className="text-slate-900 dark:text-slate-100">{editingId ? t.products.updateProduct : t.products.addProduct}</h2>
            </div>
            {editingId && (
              <Button
                type="button"
                variant="outline"
                onClick={handleCancelEdit}
                className="rounded-xl"
              >
                {t.products.cancelEdit}
              </Button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="name">{t.products.name}</Label>
                <Input
                  id="name"
                  placeholder={t.products.name}
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="rounded-xl h-12"
                  required
                />
              </div>

              <div>
                <Label htmlFor="price">{t.products.price} ({currency.code})</Label>
                <div className="flex gap-2">
                  <div className="w-16 h-12 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-400">
                    {currency.symbol}
                  </div>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    className="rounded-xl h-12 flex-1"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="description">{t.products.description}</Label>
              <Textarea
                id="description"
                placeholder={t.products.description}
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="rounded-xl min-h-24"
                required
              />
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <Label htmlFor="buyingPrice">{t.products.buyingPrice} ({currency.code})</Label>
                <div className="flex gap-2">
                  <div className="w-16 h-12 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-400">
                    {currency.symbol}
                  </div>
                  <Input
                    id="buyingPrice"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.buyingPrice}
                    onChange={(e) => setFormData({ ...formData, buyingPrice: e.target.value })}
                    className="rounded-xl h-12 flex-1"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="quantity">{t.products.quantity}</Label>
                <Input
                  id="quantity"
                  type="number"
                  placeholder="0"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  className="rounded-xl h-12"
                  required
                />
              </div>

              <div>
                <Label htmlFor="delivery">{t.products.deliveryPrice} ({currency.code})</Label>
                <div className="flex gap-2">
                  <div className="w-16 h-12 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-400">
                    {currency.symbol}
                  </div>
                  <Input
                    id="delivery"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.deliveryPrice}
                    onChange={(e) => setFormData({ ...formData, deliveryPrice: e.target.value })}
                    className="rounded-xl h-12 flex-1"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="photos">{t.products.photos}</Label>
              <div className="mt-2 flex items-center justify-center w-full h-32 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl hover:border-blue-400 dark:hover:border-blue-500 transition-colors cursor-pointer">
                <div className="text-center">
                  <Upload className="w-8 h-8 text-slate-400 dark:text-slate-500 mx-auto mb-2" />
                  <p className="text-sm text-slate-600 dark:text-slate-400">{t.products.uploadText}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-500">{t.products.uploadHint}</p>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 rounded-xl bg-gradient-to-r from-blue-500 to-violet-600 hover:from-blue-600 hover:to-violet-700"
            >
              {editingId ? (
                <>
                  <Edit className="w-5 h-5 mr-2" />
                  {t.products.updateProduct}
                </>
              ) : (
                <>
                  <Plus className="w-5 h-5 mr-2" />
                  {t.products.saveProduct}
                </>
              )}
            </Button>
          </form>
        </Card>

        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-slate-900 dark:text-slate-100">{t.products.yourProducts}</h2>
            <Select value={sortBy} onValueChange={(value: any) => setSortBy(value)}>
              <SelectTrigger className="w-48 rounded-xl">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mostSelling">{t.products.sorting.mostSelling}</SelectItem>
                <SelectItem value="mostProfiting">{t.products.sorting.mostProfiting}</SelectItem>
                <SelectItem value="lastAdded">{t.products.sorting.lastAdded}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedProducts.map((product) => (
              <Card key={product.id} className="rounded-3xl border-0 shadow-lg overflow-hidden bg-white dark:bg-slate-800">
                <div className="aspect-square bg-slate-100 dark:bg-slate-700 relative">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  {product.quantity < 20 && (
                    <Badge className="absolute top-3 right-3 bg-orange-500 dark:bg-orange-600 hover:bg-orange-600 dark:hover:bg-orange-700 rounded-full">
                      {t.products.lowStock}
                    </Badge>
                  )}
                </div>
                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="text-slate-900 dark:text-slate-100 mb-1">{product.name}</h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">{product.description}</p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-500">{t.products.price}</p>
                      <p className="text-slate-900 dark:text-slate-100">{formatPrice(product.price, currency)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-500">{t.products.quantity}</p>
                      <p className="text-slate-900 dark:text-slate-100">{product.quantity} {t.dashboard.units}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 dark:text-slate-500">{t.products.deliveryPrice}</p>
                      <p className="text-slate-900 dark:text-slate-100">{formatPrice(product.deliveryPrice, currency)}</p>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button
                      variant="outline"
                      onClick={() => handleEdit(product)}
                      className="flex-1 rounded-xl border-slate-200 dark:border-slate-700"
                    >
                      <Edit className="w-4 h-4 mr-2" />
                      {t.products.edit}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleDelete(product.id)}
                      className="flex-1 rounded-xl border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 hover:text-red-700 dark:hover:text-red-300"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      {t.products.delete}
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
